from django.apps import AppConfig


class MacdConfig(AppConfig):
    name = 'macd'
