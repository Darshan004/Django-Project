from django.shortcuts import render, redirect
from django.http import HttpResponse
from macd.models import values
import numpy as np
from .forms import InputsForm


def index(request):
    # form = InputsForm()

    if request.method == 'POST':
        # create new 'values' object
        vals = values()
        vals.hocan15 = float(request.POST['hocan15'])
        vals.g1sb015 = float(request.POST['g1sb015'])
        vals.corn15 = float(request.POST['corn15'])
        vals.hsbo15 = float(request.POST['hsbo15'])
        vals.stote_oil_blend15 = vals.g1sb015/(16.5/100)
        vals.chicken_par_fry15 = (
        vals.corn15 - vals.stote_oil_blend15*20/100)/(45/100)
        vals.macd_system_total15 = vals.stote_oil_blend15 + vals.chicken_par_fry15


        vals.hocan16 = float(request.POST['hocan16'])
        vals.g1sb016 = float(request.POST['g1sb016'])
        vals.corn16 = float(request.POST['corn16'])
        vals.hsbo16 = float(request.POST['hsbo16'])
        vals.stote_oil_blend16 = vals.g1sb016/(16.5/100)
        vals.chicken_par_fry16 = (vals.corn16 - (vals.stote_oil_blend16*20/100))/(45/100)
        vals.macd_system_total16 = vals.stote_oil_blend16 + vals.chicken_par_fry16

        vals.hocan17 = float(request.POST['hocan17'])
        vals.g1sb017 = float(request.POST['g1sb017'])
        vals.corn17 = float(request.POST['corn17'])
        vals.hsbo17 = float(request.POST['hsbo17'])
        vals.stote_oil_blend17 = vals.g1sb017/(16.5/100)
        vals.chicken_par_fry17 = (vals.corn17 - (vals.stote_oil_blend17*20/100))/(45/100)
        vals.macd_system_total17 = vals.stote_oil_blend17 + vals.chicken_par_fry17

        vals.hocan18 = float(request.POST['hocan18'])
        vals.g1sb018 = float(request.POST['g1sb018'])
        vals.corn18 = float(request.POST['corn18'])
        vals.hsbo18 = float(request.POST['hsbo18'])
        vals.stote_oil_blend18 = vals.g1sb018/(16.5/100)
        vals.chicken_par_fry18 = (vals.corn18 - (vals.stote_oil_blend18*20/100))/(45/100)
        vals.macd_system_total18 = vals.stote_oil_blend18 + vals.chicken_par_fry18

        vals.hocan19 = float(request.POST['hocan19'])
        vals.g1sb019 = float(request.POST['g1sb019'])
        vals.corn19 = float(request.POST['corn19'])
        vals.hsbo19 = float(request.POST['hsbo19'])
        vals.stote_oil_blend19 = vals.g1sb019/(16.5/100)
        vals.chicken_par_fry19 = (vals.corn19 - (vals.stote_oil_blend19*20/100))/(45/100)
        vals.macd_system_total19 = vals.stote_oil_blend19 + vals.chicken_par_fry19

        vals.hocan20 = float(request.POST['hocan20'])
        vals.g1sb020 = float(request.POST['g1sb020'])
        vals.corn20 = float(request.POST['corn20'])
        vals.hsbo20 = float(request.POST['hsbo20'])
        vals.stote_oil_blend20 = vals.g1sb020/(16.5/100)
        vals.chicken_par_fry20 = (vals.corn20 - (vals.stote_oil_blend20*20/100))/(45/100)
        vals.macd_system_total20 = vals.stote_oil_blend20 + vals.chicken_par_fry20

        vals.hocan21 = float(request.POST['hocan21'])
        vals.g1sb021 = float(request.POST['g1sb021'])
        vals.corn21 = float(request.POST['corn21'])
        vals.hsbo21 = float(request.POST['hsbo21'])
        vals.stote_oil_blend21 = vals.g1sb021/(16.5/100)
        vals.chicken_par_fry21 = (vals.corn21 - (vals.stote_oil_blend21*20/100))/(45/100)
        vals.macd_system_total21 = vals.stote_oil_blend21 + vals.chicken_par_fry21

        vals.hocan22 = float(request.POST['hocan22'])
        vals.g1sb022 = float(request.POST['g1sb022'])
        vals.corn22 = float(request.POST['corn22'])
        vals.hsbo22 = float(request.POST['hsbo22'])
        vals.stote_oil_blend22 = vals.g1sb022/(16.5/100)
        vals.chicken_par_fry22 = (vals.corn22 - (vals.stote_oil_blend22*20/100))/(45/100)
        vals.macd_system_total22 = vals.stote_oil_blend22 + vals.chicken_par_fry22

        vals.hocan23 = float(request.POST['hocan23'])
        vals.g1sb023 = float(request.POST['g1sb023'])
        vals.corn23 = float(request.POST['corn23'])
        vals.hsbo23 = float(request.POST['hsbo23'])
        vals.stote_oil_blend23 = vals.g1sb023/(16.5/100)
        vals.chicken_par_fry23 = (vals.corn23 - (vals.stote_oil_blend23*20/100))/(45/100)
        vals.macd_system_total23 = vals.stote_oil_blend23 + vals.chicken_par_fry23

        vals.hocan24 = float(request.POST['hocan24'])
        vals.g1sb024 = float(request.POST['g1sb024'])
        vals.corn24 = float(request.POST['corn24'])
        vals.hsbo24 = float(request.POST['hsbo24'])
        vals.stote_oil_blend24 = vals.g1sb024/(16.5/100)
        vals.chicken_par_fry24 = (vals.corn24 - (vals.stote_oil_blend24*20/100))/(45/100)
        vals.macd_system_total24 = vals.stote_oil_blend24 + vals.chicken_par_fry24

        vals.rhpko15 = float(request.POST['rhpko15'])
        vals.rhpkol15 = float(request.POST['rhpkol15'])
        vals.rhpkst15 = float(request.POST['rhpkst15'])
        vals.shortening15 = float(request.POST['shortening15'])
        vals.rhpo15 = float(request.POST['rhpo15'])
        vals.rpst15 = float(request.POST['rpst15'])
        vals.rhpst15 = float(request.POST['rhpst15'])
        vals.rhcno15 = float(request.POST['rhcno15'])
        vals.rcno15 = float(request.POST['rcno15'])
        vals.rpko15 = float(request.POST['rpko15'])
        vals.subtotal15 =( vals.rhpko15 + vals.rhpkol15 + vals.rhpkst15 + vals.shortening15 + vals.rhpo15 + vals.rpst15 + 
                        vals.rhpst15 + vals.rhcno15 + vals.rcno15 + vals.rpko15 )

        vals.rhpko16 = float(request.POST['rhpko16'])
        vals.rhpkol16 = float(request.POST['rhpkol16'])
        vals.rhpkst16 = float(request.POST['rhpkst16'])
        vals.shortening16 = float(request.POST['shortening16'])
        vals.rhpo16 = float(request.POST['rhpo16'])
        vals.rpst16 = float(request.POST['rpst16'])
        vals.rhpst16 = float(request.POST['rhpst16'])
        vals.rhcno16 = float(request.POST['rhcno16'])
        vals.rcno16 = float(request.POST['rcno16'])
        vals.rpko16 = float(request.POST['rpko16'])
        vals.subtotal16 =( vals.rhpko16 + vals.rhpkol16 + vals.rhpkst16 + vals.shortening16 + vals.rhpo16 + vals.rpst16 + 
                        vals.rhpst16 + vals.rhcno16 + vals.rcno16 + vals.rpko16 )
                            
        vals.rhpko17 = float(request.POST['rhpko17'])
        vals.rhpkol17 = float(request.POST['rhpkol17'])
        vals.rhpkst17 = float(request.POST['rhpkst17'])
        vals.shortening17 = float(request.POST['shortening17'])
        vals.rhpo17 = float(request.POST['rhpo17'])
        vals.rpst17 = float(request.POST['rpst17'])
        vals.rhpst17 = float(request.POST['rhpst17'])
        vals.rhcno17 = float(request.POST['rhcno17'])
        vals.rcno17 = float(request.POST['rcno17'])
        vals.rpko17 = float(request.POST['rpko17'])
        vals.subtotal17 =( vals.rhpko17 + vals.rhpkol17 + vals.rhpkst17 + vals.shortening17 + vals.rhpo17 + vals.rpst17 + 
                        vals.rhpst17 + vals.rhcno17 + vals.rcno17 + vals.rpko17 )                    

        vals.rhpko18 = float(request.POST['rhpko18'])
        vals.rhpkol18 = float(request.POST['rhpkol18'])
        vals.rhpkst18 = float(request.POST['rhpkst18'])
        vals.shortening18 = float(request.POST['shortening18'])
        vals.rhpo18 = float(request.POST['rhpo18'])
        vals.rpst18 = float(request.POST['rpst18'])
        vals.rhpst18 = float(request.POST['rhpst18'])
        vals.rhcno18 = float(request.POST['rhcno18'])
        vals.rcno18 = float(request.POST['rcno18'])
        vals.rpko18 = float(request.POST['rpko18'])
        vals.subtotal18 =( vals.rhpko18 + vals.rhpkol18 + vals.rhpkst18 + vals.shortening18 + vals.rhpo18 + vals.rpst18 + 
                        vals.rhpst18 + vals.rhcno18 + vals.rcno18 + vals.rpko18 )

        vals.rhpko19 = float(request.POST['rhpko19'])
        vals.rhpkol19 = float(request.POST['rhpkol19'])
        vals.rhpkst19 = float(request.POST['rhpkst19'])
        vals.shortening19 = float(request.POST['shortening19'])
        vals.rhpo19 = float(request.POST['rhpo19'])
        vals.rpst19 = float(request.POST['rpst19'])
        vals.rhpst19 = float(request.POST['rhpst19'])
        vals.rhcno19 = float(request.POST['rhcno19'])
        vals.rcno19 = float(request.POST['rcno19'])
        vals.rpko19 = float(request.POST['rpko19'])
        vals.subtotal19 =( vals.rhpko19 + vals.rhpkol19 + vals.rhpkst19 + vals.shortening19 + vals.rhpo19 + vals.rpst19 + 
                        vals.rhpst19 + vals.rhcno19 + vals.rcno19 + vals.rpko19 )

        vals.rhpko20 = float(request.POST['rhpko20'])
        vals.rhpkol20 = float(request.POST['rhpkol20'])
        vals.rhpkst20 = float(request.POST['rhpkst20'])
        vals.shortening20 = float(request.POST['shortening20'])
        vals.rhpo20 = float(request.POST['rhpo20'])
        vals.rpst20 = float(request.POST['rpst20'])
        vals.rhpst20 = float(request.POST['rhpst20'])
        vals.rhcno20 = float(request.POST['rhcno20'])
        vals.rcno20 = float(request.POST['rcno20'])
        vals.rpko20 = float(request.POST['rpko20'])
        vals.subtotal20 =( vals.rhpko20 + vals.rhpkol20 + vals.rhpkst20 + vals.shortening20 + vals.rhpo20 + vals.rpst20 + 
                        vals.rhpst20 + vals.rhcno20 + vals.rcno20 + vals.rpko20 )

        vals.rhpko21 = float(request.POST['rhpko21'])
        vals.rhpkol21 = float(request.POST['rhpkol21'])
        vals.rhpkst21 = float(request.POST['rhpkst21'])
        vals.shortening21 = float(request.POST['shortening21'])
        vals.rhpo21 = float(request.POST['rhpo21'])
        vals.rpst21 = float(request.POST['rpst21'])
        vals.rhpst21 = float(request.POST['rhpst21'])
        vals.rhcno21 = float(request.POST['rhcno21'])
        vals.rcno21 = float(request.POST['rcno21'])
        vals.rpko21 = float(request.POST['rpko21'])
        vals.subtotal21 =( vals.rhpko21 + vals.rhpkol21 + vals.rhpkst21 + vals.shortening21 + vals.rhpo21 + vals.rpst21 + 
                        vals.rhpst21 + vals.rhcno21 + vals.rcno21 + vals.rpko21 )

        vals.rhpko22 = float(request.POST['rhpko22'])
        vals.rhpkol22 = float(request.POST['rhpkol22'])
        vals.rhpkst22 = float(request.POST['rhpkst22'])
        vals.shortening22 = float(request.POST['shortening22'])
        vals.rhpo22 = float(request.POST['rhpo22'])
        vals.rpst22 = float(request.POST['rpst22'])
        vals.rhpst22 = float(request.POST['rhpst22'])
        vals.rhcno22 = float(request.POST['rhcno22'])
        vals.rcno22 = float(request.POST['rcno22'])
        vals.rpko22 = float(request.POST['rpko22'])
        vals.subtotal22 =( vals.rhpko22 + vals.rhpkol22 + vals.rhpkst22 + vals.shortening22 + vals.rhpo22 + vals.rpst22 + 
                        vals.rhpst22 + vals.rhcno22 + vals.rcno22 + vals.rpko22 )

        vals.rhpko23 = float(request.POST['rhpko23'])
        vals.rhpkol23 = float(request.POST['rhpkol23'])
        vals.rhpkst23 = float(request.POST['rhpkst23'])
        vals.shortening23 = float(request.POST['shortening23'])
        vals.rhpo23 = float(request.POST['rhpo23'])
        vals.rpst23 = float(request.POST['rpst23'])
        vals.rhpst23 = float(request.POST['rhpst23'])
        vals.rhcno23 = float(request.POST['rhcno23'])
        vals.rcno23 = float(request.POST['rcno23'])
        vals.rpko23 = float(request.POST['rpko23'])
        vals.subtotal23 =( vals.rhpko23 + vals.rhpkol23 + vals.rhpkst23 + vals.shortening23 + vals.rhpo23 + vals.rpst23 + 
                        vals.rhpst23 + vals.rhcno23 + vals.rcno23 + vals.rpko23 )

        vals.rhpko24 = float(request.POST['rhpko24'])
        vals.rhpkol24 = float(request.POST['rhpkol24'])
        vals.rhpkst24 = float(request.POST['rhpkst24'])
        vals.shortening24 = float(request.POST['shortening24'])
        vals.rhpo24 = float(request.POST['rhpo24'])
        vals.rpst24 = float(request.POST['rpst24'])
        vals.rhpst24 = float(request.POST['rhpst24'])
        vals.rhcno24 = float(request.POST['rhcno24'])
        vals.rcno24 = float(request.POST['rcno24'])
        vals.rpko24 = float(request.POST['rpko24'])
        vals.subtotal24 =( vals.rhpko24 + vals.rhpkol24 + vals.rhpkst24 + vals.shortening24 + vals.rhpo24 + vals.rpst24 + 
                        vals.rhpst24 + vals.rhcno24 + vals.rcno24 + vals.rpko24 )

        vals.apshortening15 = float(request.POST['apshortening15'])
        vals.rhpo15 = float(request.POST['rhpo15'])
        vals.rhsbo15 = float(request.POST['rhsbo15'])
        vals.subtotal_15 = vals.apshortening15 + vals.rhsbo15 + vals.rhpo15
        vals.sf_total15 = vals.subtotal_15 + vals.subtotal15

        vals.apshortening16 = float(request.POST['apshortening16'])
        vals.rhpo16 = float(request.POST['rhpo16'])
        vals.rhsbo16 = float(request.POST['rhsbo16'])
        vals.subtotal_16 = vals.apshortening16 + vals.rhsbo16 + vals.rhpo16
        vals.sf_total16 = vals.subtotal_16 + vals.subtotal16

        vals.apshortening17 = float(request.POST['apshortening17'])
        vals.rhpo17 = float(request.POST['rhpo17'])
        vals.rhsbo17 = float(request.POST['rhsbo17'])
        vals.subtotal_17 = vals.apshortening17 + vals.rhsbo17 + vals.rhpo17
        vals.sf_total17 = vals.subtotal_17 + vals.subtotal17

        vals.apshortening18 = float(request.POST['apshortening18'])
        vals.rhpo18 = float(request.POST['rhpo18'])
        vals.rhsbo18 = float(request.POST['rhsbo18'])
        vals.subtotal_18 = vals.apshortening18 + vals.rhsbo18 + vals.rhpo18
        vals.sf_total18 = vals.subtotal_18 + vals.subtotal18

        vals.apshortening19 = float(request.POST['apshortening19'])
        vals.rhpo19 = float(request.POST['rhpo19'])
        vals.rhsbo19 = float(request.POST['rhsbo19'])
        vals.subtotal_19 = vals.apshortening19 + vals.rhsbo19 + vals.rhpo19
        vals.sf_total19 = vals.subtotal_19 + vals.subtotal19

        vals.apshortening20 = float(request.POST['apshortening20'])
        vals.rhpo20 = float(request.POST['rhpo20'])
        vals.rhsbo20 = float(request.POST['rhsbo20'])
        vals.subtotal_20 = vals.apshortening20 + vals.rhsbo20 + vals.rhpo20
        vals.sf_total20 = vals.subtotal_20 + vals.subtotal20

        vals.apshortening21 = float(request.POST['apshortening21'])
        vals.rhpo21 = float(request.POST['rhpo21'])
        vals.rhsbo21 = float(request.POST['rhsbo21'])
        vals.subtotal_21 = vals.apshortening21 + vals.rhsbo21 + vals.rhpo21
        vals.sf_total21 = vals.subtotal_21 + vals.subtotal21

        vals.apshortening22 = float(request.POST['apshortening22'])
        vals.rhpo22 = float(request.POST['rhpo22'])
        vals.rhsbo22 = float(request.POST['rhsbo22'])
        vals.subtotal_22 = vals.apshortening22 + vals.rhsbo22 + vals.rhpo22
        vals.sf_total22 = vals.subtotal_22 + vals.subtotal22

        vals.apshortening23 = float(request.POST['apshortening23'])
        vals.rhpo23 = float(request.POST['rhpo23'])
        vals.rhsbo23 = float(request.POST['rhsbo23'])
        vals.subtotal_23 = vals.apshortening23 + vals.rhsbo23 + vals.rhpo23
        vals.sf_total23 = vals.subtotal_23 + vals.subtotal23

        vals.apshortening24 = float(request.POST['apshortening24'])
        vals.rhpo24 = float(request.POST['rhpo24'])
        vals.rhsbo24 = float(request.POST['rhsbo24'])
        vals.subtotal_24 = vals.apshortening24 + vals.rhsbo24 + vals.rhpo24
        vals.sf_total24 = vals.subtotal_24 + vals.subtotal24

        vals.g1sbo15 = float(request.POST['g1sbo15'])
        vals.blendedoil15 = float(request.POST['blendedoil15'])
        vals.rol15 = float(request.POST['rol15'])
        vals.spmf15 = float(request.POST['spmf15'])
        vals.mpbtotal15 = vals.g1sbo15 + vals.blendedoil15 + vals.rol15 + vals.spmf15

        vals.g1sbo16 = float(request.POST['g1sbo16'])
        vals.blendedoil16 = float(request.POST['blendedoil16'])
        vals.rol16 = float(request.POST['rol16'])
        vals.spmf16 = float(request.POST['spmf16'])
        vals.mpbtotal16 = vals.g1sbo16 + vals.blendedoil16 + vals.rol16 + vals.spmf16

        vals.g1sbo17 = float(request.POST['g1sbo17'])
        vals.blendedoil17 = float(request.POST['blendedoil17'])
        vals.rol17 = float(request.POST['rol17'])
        vals.spmf17 = float(request.POST['spmf17'])
        vals.mpbtotal17 = vals.g1sbo17 + vals.blendedoil17 + vals.rol17 + vals.spmf17

        vals.g1sbo18 = float(request.POST['g1sbo18'])
        vals.blendedoil18 = float(request.POST['blendedoil18'])
        vals.rol18 = float(request.POST['rol18'])
        vals.spmf18 = float(request.POST['spmf18'])
        vals.mpbtotal18 = vals.g1sbo18 + vals.blendedoil18 + vals.rol18 + vals.spmf18

        vals.g1sbo19 = float(request.POST['g1sbo19'])
        vals.blendedoil19 = float(request.POST['blendedoil19'])
        vals.rol19 = float(request.POST['rol19'])
        vals.spmf19 = float(request.POST['spmf19'])
        vals.mpbtotal19 = vals.g1sbo19 + vals.blendedoil19 + vals.rol19 + vals.spmf19

        vals.g1sbo20 = float(request.POST['g1sbo20'])
        vals.blendedoil20 = float(request.POST['blendedoil20'])
        vals.rol20 = float(request.POST['rol20'])
        vals.spmf20 = float(request.POST['spmf20'])
        vals.mpbtotal20 = vals.g1sbo20 + vals.blendedoil20 + vals.rol20 + vals.spmf20

        vals.g1sbo21 = float(request.POST['g1sbo21'])
        vals.blendedoil21 = float(request.POST['blendedoil21'])
        vals.rol21 = float(request.POST['rol21'])
        vals.spmf21 = float(request.POST['spmf21'])
        vals.mpbtotal21 = vals.g1sbo21 + vals.blendedoil21 + vals.rol21 + vals.spmf21

        vals.g1sbo22 = float(request.POST['g1sbo22'])
        vals.blendedoil22 = float(request.POST['blendedoil22'])
        vals.rol22 = float(request.POST['rol22'])
        vals.spmf22 = float(request.POST['spmf22'])
        vals.mpbtotal22 = vals.g1sbo22 + vals.blendedoil22 + vals.rol22 + vals.spmf22

        vals.g1sbo23 = float(request.POST['g1sbo23'])
        vals.blendedoil23 = float(request.POST['blendedoil23'])
        vals.rol23 = float(request.POST['rol23'])
        vals.spmf23 = float(request.POST['spmf23'])
        vals.mpbtotal23 = vals.g1sbo23 + vals.blendedoil23 + vals.rol23 + vals.spmf23

        vals.g1sbo24 = float(request.POST['g1sbo24'])
        vals.blendedoil24 = float(request.POST['blendedoil24'])
        vals.rol24 = float(request.POST['rol24'])
        vals.spmf24 = float(request.POST['spmf24'])
        vals.mpbtotal24 = vals.g1sbo24 + vals.blendedoil24 + vals.rol24 + vals.spmf24

        vals.g1sbo1_15 = float(request.POST['g1sbo1_15'])
        vals.g1sbo2_15 = float(request.POST['g1sbo2_15'])
        vals.g1sbo3_15 = float(request.POST['g1sbo3_15'])
        vals.g1sbo4_15 = float(request.POST['g1sbo4_15'])
        vals.blendedoil1_15 = float(request.POST['blendedoil1_15'])
        vals.blendedoil2_15 = float(request.POST['blendedoil2_15'])
        vals.blendedoil3_15 = float(request.POST['blendedoil3_15'])
        vals.blendedoil4_15 = float(request.POST['blendedoil4_15'])
        vals.superolein1_15 = float(request.POST['superolein1_15'])
        vals.superolein2_15 = float(request.POST['superolein2_15'])
        vals.superolein3_15 = float(request.POST['superolein3_15'])
        vals.superolein4_15 = float(request.POST['superolein4_15'])
        vals.mpptotal15 = (vals.g1sbo1_15 + vals.g1sbo2_15 + vals.g1sbo3_15 + vals.g1sbo4_15 +
                                vals.blendedoil1_15 + vals.blendedoil2_15 + vals.blendedoil3_15 + vals.blendedoil4_15 +  
                                    vals.superolein1_15 + vals.superolein2_15 + vals.superolein3_15 + vals.superolein4_15)

        vals.g1sbo1_16 = float(request.POST['g1sbo1_16'])
        vals.g1sbo2_16 = float(request.POST['g1sbo2_16'])
        vals.g1sbo3_16 = float(request.POST['g1sbo3_16'])
        vals.g1sbo4_16 = float(request.POST['g1sbo4_16'])
        vals.blendedoil1_16 = float(request.POST['blendedoil1_16'])
        vals.blendedoil2_16 = float(request.POST['blendedoil2_16'])
        vals.blendedoil3_16 = float(request.POST['blendedoil3_16'])
        vals.blendedoil4_16 = float(request.POST['blendedoil4_16'])
        vals.superolein1_16 = float(request.POST['superolein1_16'])
        vals.superolein2_16 = float(request.POST['superolein2_16'])
        vals.superolein3_16 = float(request.POST['superolein3_16'])
        vals.superolein4_16 = float(request.POST['superolein4_16'])
        vals.mpptotal16 =( vals.g1sbo1_16 + vals.g1sbo2_16 + vals.g1sbo3_16 + vals.g1sbo4_16 +
                                vals.blendedoil1_16 + vals.blendedoil2_16 + vals.blendedoil3_16 + vals.blendedoil4_16 +  
                                    vals.superolein1_16 + vals.superolein2_16 + vals.superolein3_16 + vals.superolein4_16 )

        vals.g1sbo1_17 = float(request.POST['g1sbo1_17'])
        vals.g1sbo2_17 = float(request.POST['g1sbo2_17'])
        vals.g1sbo3_17 = float(request.POST['g1sbo3_17'])
        vals.g1sbo4_17 = float(request.POST['g1sbo4_17'])
        vals.blendedoil1_17 = float(request.POST['blendedoil1_17'])
        vals.blendedoil2_17 = float(request.POST['blendedoil2_17'])
        vals.blendedoil3_17 = float(request.POST['blendedoil3_17'])
        vals.blendedoil4_17 = float(request.POST['blendedoil4_17'])
        vals.superolein1_17 = float(request.POST['superolein1_17'])
        vals.superolein2_17 = float(request.POST['superolein2_17'])
        vals.superolein3_17 = float(request.POST['superolein3_17'])
        vals.superolein4_17 = float(request.POST['superolein4_17'])
        vals.mpptotal17 = (vals.g1sbo1_17 + vals.g1sbo2_17 + vals.g1sbo3_17 + vals.g1sbo4_17 +
                                vals.blendedoil1_17 + vals.blendedoil2_17 + vals.blendedoil3_17 + vals.blendedoil4_17 +  
                                    vals.superolein1_17 + vals.superolein2_17 + vals.superolein3_17 + vals.superolein4_17)

        vals.g1sbo1_18 = float(request.POST['g1sbo1_18'])
        vals.g1sbo2_18 = float(request.POST['g1sbo2_18'])
        vals.g1sbo3_18 = float(request.POST['g1sbo3_18'])
        vals.g1sbo4_18 = float(request.POST['g1sbo4_18'])
        vals.blendedoil1_18 = float(request.POST['blendedoil1_18'])
        vals.blendedoil2_18 = float(request.POST['blendedoil2_18'])
        vals.blendedoil3_18 = float(request.POST['blendedoil3_18'])
        vals.blendedoil4_18 = float(request.POST['blendedoil4_18'])
        vals.superolein1_18 = float(request.POST['superolein1_18'])
        vals.superolein2_18 = float(request.POST['superolein2_18'])
        vals.superolein3_18 = float(request.POST['superolein3_18'])
        vals.superolein4_18 = float(request.POST['superolein4_18'])
        vals.mpptotal18 =( vals.g1sbo1_18 + vals.g1sbo2_18 + vals.g1sbo3_18 + vals.g1sbo4_18 +
                                vals.blendedoil1_18 + vals.blendedoil2_18 + vals.blendedoil3_18 + vals.blendedoil4_18 +  
                                    vals.superolein1_18 + vals.superolein2_18 + vals.superolein3_18 + vals.superolein4_18)

        vals.g1sbo1_19 = float(request.POST['g1sbo1_19'])
        vals.g1sbo2_19 = float(request.POST['g1sbo2_19'])
        vals.g1sbo3_19 = float(request.POST['g1sbo3_19'])
        vals.g1sbo4_19 = float(request.POST['g1sbo4_19'])
        vals.blendedoil1_19 = float(request.POST['blendedoil1_19'])
        vals.blendedoil2_19 = float(request.POST['blendedoil2_19'])
        vals.blendedoil3_19 = float(request.POST['blendedoil3_19'])
        vals.blendedoil4_19 = float(request.POST['blendedoil4_19'])
        vals.superolein1_19 = float(request.POST['superolein1_19'])
        vals.superolein2_19 = float(request.POST['superolein2_19'])
        vals.superolein3_19 = float(request.POST['superolein3_19'])
        vals.superolein4_19 = float(request.POST['superolein4_19'])
        vals.mpptotal19 = (vals.g1sbo1_19 + vals.g1sbo2_19 + vals.g1sbo3_19 + vals.g1sbo4_19 +
                                vals.blendedoil1_19 + vals.blendedoil2_19 + vals.blendedoil3_19 + vals.blendedoil4_19 +  
                                    vals.superolein1_19 + vals.superolein2_19 + vals.superolein3_19 + vals.superolein4_19)

        vals.g1sbo1_20 = float(request.POST['g1sbo1_20'])
        vals.g1sbo2_20 = float(request.POST['g1sbo2_20'])
        vals.g1sbo3_20 = float(request.POST['g1sbo3_20'])
        vals.g1sbo4_20 = float(request.POST['g1sbo4_20'])
        vals.blendedoil1_20 = float(request.POST['blendedoil1_20'])
        vals.blendedoil2_20 = float(request.POST['blendedoil2_20'])
        vals.blendedoil3_20 = float(request.POST['blendedoil3_20'])
        vals.blendedoil4_20 = float(request.POST['blendedoil4_20'])
        vals.superolein1_20 = float(request.POST['superolein1_20'])
        vals.superolein2_20 = float(request.POST['superolein2_20'])
        vals.superolein3_20 = float(request.POST['superolein3_20'])
        vals.superolein4_20 = float(request.POST['superolein4_20'])
        vals.mpptotal20 = (vals.g1sbo1_20 + vals.g1sbo2_20 + vals.g1sbo3_20 + vals.g1sbo4_20 +
                                vals.blendedoil1_20 + vals.blendedoil2_20 + vals.blendedoil3_20 + vals.blendedoil4_20 +  
                                    vals.superolein1_20 + vals.superolein2_20 + vals.superolein3_20 + vals.superolein4_20)

        vals.g1sbo1_21 = float(request.POST['g1sbo1_21'])
        vals.g1sbo2_21 = float(request.POST['g1sbo2_21'])
        vals.g1sbo3_21 = float(request.POST['g1sbo3_21'])
        vals.g1sbo4_21 = float(request.POST['g1sbo4_21'])
        vals.blendedoil1_21 = float(request.POST['blendedoil1_21'])
        vals.blendedoil2_21 = float(request.POST['blendedoil2_21'])
        vals.blendedoil3_21 = float(request.POST['blendedoil3_21'])
        vals.blendedoil4_21 = float(request.POST['blendedoil4_21'])
        vals.superolein1_21 = float(request.POST['superolein1_21'])
        vals.superolein2_21 = float(request.POST['superolein2_21'])
        vals.superolein3_21 = float(request.POST['superolein3_21'])
        vals.superolein4_21 = float(request.POST['superolein4_21'])
        vals.mpptotal21 = (vals.g1sbo1_21 + vals.g1sbo2_21 + vals.g1sbo3_21 + vals.g1sbo4_21 +
                                vals.blendedoil1_21 + vals.blendedoil2_21 + vals.blendedoil3_21 + vals.blendedoil4_21 +  
                                    vals.superolein1_21 + vals.superolein2_21 + vals.superolein3_21 + vals.superolein4_21)

        vals.g1sbo1_22 = float(request.POST['g1sbo1_22'])
        vals.g1sbo2_22 = float(request.POST['g1sbo2_22'])
        vals.g1sbo3_22 = float(request.POST['g1sbo3_22'])
        vals.g1sbo4_22 = float(request.POST['g1sbo4_22'])
        vals.blendedoil1_22 = float(request.POST['blendedoil1_22'])
        vals.blendedoil2_22 = float(request.POST['blendedoil2_22'])
        vals.blendedoil3_22 = float(request.POST['blendedoil3_22'])
        vals.blendedoil4_22 = float(request.POST['blendedoil4_22'])
        vals.superolein1_22 = float(request.POST['superolein1_22'])
        vals.superolein2_22 = float(request.POST['superolein2_22'])
        vals.superolein3_22 = float(request.POST['superolein3_22'])
        vals.superolein4_22 = float(request.POST['superolein4_22'])
        vals.mpptotal22 = (vals.g1sbo1_22 + vals.g1sbo2_22 + vals.g1sbo3_22 + vals.g1sbo4_22 +
                                vals.blendedoil1_22 + vals.blendedoil2_22 + vals.blendedoil3_22 + vals.blendedoil4_22 +  
                                    vals.superolein1_22 + vals.superolein2_22 + vals.superolein3_22 + vals.superolein4_22)

        vals.g1sbo1_23 = float(request.POST['g1sbo1_23'])
        vals.g1sbo2_23 = float(request.POST['g1sbo2_23'])
        vals.g1sbo3_23 = float(request.POST['g1sbo3_23'])
        vals.g1sbo4_23 = float(request.POST['g1sbo4_23'])
        vals.blendedoil1_23 = float(request.POST['blendedoil1_23'])
        vals.blendedoil2_23 = float(request.POST['blendedoil2_23'])
        vals.blendedoil3_23 = float(request.POST['blendedoil3_23'])
        vals.blendedoil4_23 = float(request.POST['blendedoil4_23'])
        vals.superolein1_23 = float(request.POST['superolein1_23'])
        vals.superolein2_23 = float(request.POST['superolein2_23'])
        vals.superolein3_23 = float(request.POST['superolein3_23'])
        vals.superolein4_23 = float(request.POST['superolein4_23'])
        vals.mpptotal23 = (vals.g1sbo1_23 + vals.g1sbo2_23 + vals.g1sbo3_23 + vals.g1sbo4_23 +
                                vals.blendedoil1_23 + vals.blendedoil2_23 + vals.blendedoil3_23 + vals.blendedoil4_23 +  
                                    vals.superolein1_23 + vals.superolein2_23 + vals.superolein3_23 + vals.superolein4_23)

        vals.g1sbo1_24 = float(request.POST['g1sbo1_24'])
        vals.g1sbo2_24 = float(request.POST['g1sbo2_24'])
        vals.g1sbo3_24 = float(request.POST['g1sbo3_24'])
        vals.g1sbo4_24 = float(request.POST['g1sbo4_24'])
        vals.blendedoil1_24 = float(request.POST['blendedoil1_24'])
        vals.blendedoil2_24 = float(request.POST['blendedoil2_24'])
        vals.blendedoil3_24 = float(request.POST['blendedoil3_24'])
        vals.blendedoil4_24 = float(request.POST['blendedoil4_24'])
        vals.superolein1_24 = float(request.POST['superolein1_24'])
        vals.superolein2_24 = float(request.POST['superolein2_24'])
        vals.superolein3_24 = float(request.POST['superolein3_24'])
        vals.superolein4_24 = float(request.POST['superolein4_24'])
        vals.mpptotal24 = (vals.g1sbo1_24 + vals.g1sbo2_24 + vals.g1sbo3_24 + vals.g1sbo4_24 +
                                vals.blendedoil1_24 + vals.blendedoil2_24 + vals.blendedoil3_24 + vals.blendedoil4_24 +  
                                    vals.superolein1_24 + vals.superolein2_24 + vals.superolein3_24 + vals.superolein4_24)


        vals.ls15 = float(request.POST['ls15'])
        vals.nis15 = float(request.POST['nis15'])
        vals.nim15 = float(request.POST['nim15'])
        vals.is15 = float(request.POST['is15'])
        vals.im15 = float(request.POST['im15'])
        vals.asm15 = float(request.POST['asm15'])
        vals.bot15 = vals.ls15 + vals.nis15 + vals.nim15 + vals.is15 + vals.im15 + vals.asm15

        vals.ls16 = float(request.POST['ls16'])
        vals.nis16 = float(request.POST['nis16'])
        vals.nim16 = float(request.POST['nim16'])
        vals.is16 = float(request.POST['is16'])
        vals.im16 = float(request.POST['im16'])
        vals.asm16 = float(request.POST['asm16'])
        vals.bot16 = vals.ls16 + vals.nis16 + vals.nim16 + vals.is16 + vals.im16 + vals.asm16

        vals.ls17 = float(request.POST['ls17'])
        vals.nis17 = float(request.POST['nis17'])
        vals.nim17 = float(request.POST['nim17'])
        vals.is17 = float(request.POST['is17'])
        vals.im17 = float(request.POST['im17'])
        vals.asm17 = float(request.POST['asm17'])
        vals.bot17 = vals.ls17 + vals.nis17 + vals.nim17 + vals.is17 + vals.im17 + vals.asm17

        vals.ls18 = float(request.POST['ls18'])
        vals.nis18 = float(request.POST['nis18'])
        vals.nim18 = float(request.POST['nim18'])
        vals.is18 = float(request.POST['is18'])
        vals.im18 = float(request.POST['im18'])
        vals.asm18 = float(request.POST['asm18'])
        vals.bot18 = vals.ls18 + vals.nis18 + vals.nim18 + vals.is18 + vals.im18 + vals.asm18

        vals.ls19 = float(request.POST['ls19'])
        vals.nis19 = float(request.POST['nis19'])
        vals.nim19 = float(request.POST['nim19'])
        vals.is19 = float(request.POST['is19'])
        vals.im19 = float(request.POST['im19'])
        vals.asm19 = float(request.POST['asm19'])
        vals.bot19 = vals.ls19 + vals.nis19 + vals.nim19 + vals.is19 + vals.im19 + vals.asm19

        vals.ls20 = float(request.POST['ls20'])
        vals.nis20 = float(request.POST['nis20'])
        vals.nim20 = float(request.POST['nim20'])
        vals.is20 = float(request.POST['is20'])
        vals.im20 = float(request.POST['im20'])
        vals.asm20 = float(request.POST['asm20'])
        vals.bot20 = vals.ls20 + vals.nis20 + vals.nim20 + vals.is20 + vals.im20 + vals.asm20

        vals.ls21 = float(request.POST['ls21'])
        vals.nis21 = float(request.POST['nis21'])
        vals.nim21 = float(request.POST['nim21'])
        vals.is21 = float(request.POST['is21'])
        vals.im21 = float(request.POST['im21'])
        vals.asm21 = float(request.POST['asm21'])
        vals.bot21 = vals.ls21 + vals.nis21 + vals.nim21 + vals.is21 + vals.im21 + vals.asm21

        vals.ls22 = float(request.POST['ls22'])
        vals.nis22 = float(request.POST['nis22'])
        vals.nim22 = float(request.POST['nim22'])
        vals.is22 = float(request.POST['is22'])
        vals.im22 = float(request.POST['im22'])
        vals.asm22 = float(request.POST['asm22'])
        vals.bot22 = vals.ls22 + vals.nis22 + vals.nim22 + vals.is22 + vals.im22 + vals.asm22

        vals.ls23 = float(request.POST['ls23'])
        vals.nis23 = float(request.POST['nis23'])
        vals.nim23 = float(request.POST['nim23'])
        vals.is23 = float(request.POST['is23'])
        vals.im23 = float(request.POST['im23'])
        vals.asm23 = float(request.POST['asm23'])
        vals.bot23 = vals.ls23 + vals.nis23 + vals.nim23 + vals.is23 + vals.im23 + vals.asm23

        vals.ls24 = float(request.POST['ls24'])
        vals.nis24 = float(request.POST['nis24'])
        vals.nim24 = float(request.POST['nim24'])
        vals.is24 = float(request.POST['is24'])
        vals.im24 = float(request.POST['im24'])
        vals.asm24 = float(request.POST['asm24'])
        vals.bot24 = vals.ls24 + vals.nis24 + vals.nim24 + vals.is24 + vals.im24 + vals.asm24

        vals.tvp15 = vals.bot15 + vals.mpptotal15 + vals.mpbtotal15 + vals.sf_total15 + vals.macd_system_total15
        vals.bulk15 = (vals.chicken_par_fry15 + vals.rhpko15 + vals.rhpkol15 + vals.rhpkst15 + vals.shortening15 +
                        vals.rhpo15 + vals.rpst15 + vals.rhpst15 + vals.rhcno15 + vals.rcno15)
        vals.packaged15 = (vals.stote_oil_blend15 + vals.subtotal_15 + vals.ls15 + vals.nim15 + 
                            vals.nis15 + vals.is15 + vals.im15 + vals.asm15)

        vals.tvp16 = vals.bot16 + vals.mpptotal16 + vals.mpbtotal16 + vals.sf_total16 + vals.macd_system_total16
        vals.bulk16 = (vals.chicken_par_fry16 + vals.rhpko16 + vals.rhpkol16 + vals.rhpkst16 + vals.shortening16 +
                        vals.rhpo16 + vals.rpst16 + vals.rhpst16 + vals.rhcno16 + vals.rcno16)
        vals.packaged16 = (vals.stote_oil_blend16 + vals.subtotal_16 + vals.ls16 + vals.nim16 + 
                            vals.nis16 + vals.is16 + vals.im16 + vals.asm16)

        vals.tvp17 = vals.bot17 + vals.mpptotal17 + vals.mpbtotal17 + vals.sf_total17 + vals.macd_system_total17
        vals.bulk17 = (vals.chicken_par_fry17 + vals.rhpko17 + vals.rhpkol17 + vals.rhpkst17 + vals.shortening17 +
                        vals.rhpo17 + vals.rpst17 + vals.rhpst17 + vals.rhcno17 + vals.rcno17)
        vals.packaged17 = (vals.stote_oil_blend17 + vals.subtotal_17 + vals.ls17 + vals.nim17 + 
                            vals.nis17 + vals.is17 + vals.im17 + vals.asm17)

        vals.tvp18 = vals.bot18 + vals.mpptotal18 + vals.mpbtotal18 + vals.sf_total18 + vals.macd_system_total18
        vals.bulk18 = (vals.chicken_par_fry18 + vals.rhpko18 + vals.rhpkol18 + vals.rhpkst18 + vals.shortening18 +
                        vals.rhpo18 + vals.rpst18 + vals.rhpst18 + vals.rhcno18 + vals.rcno18)
        vals.packaged18 = (vals.stote_oil_blend18 + vals.subtotal_18 + vals.ls18 + vals.nim18 + 
                            vals.nis18 + vals.is18 + vals.im18 + vals.asm18)

        vals.tvp19 = vals.bot19 + vals.mpptotal19 + vals.mpbtotal19 + vals.sf_total19 + vals.macd_system_total19
        vals.bulk19 = (vals.chicken_par_fry19 + vals.rhpko19 + vals.rhpkol19 + vals.rhpkst19 + vals.shortening19 +
                        vals.rhpo19 + vals.rpst19 + vals.rhpst19 + vals.rhcno19 + vals.rcno19)
        vals.packaged19 = (vals.stote_oil_blend19 + vals.subtotal_19 + vals.ls19 + vals.nim19 + 
                            vals.nis19 + vals.is19 + vals.im19 + vals.asm19)

        vals.tvp20 = vals.bot20 + vals.mpptotal20 + vals.mpbtotal20 + vals.sf_total20 + vals.macd_system_total20
        vals.bulk20 = (vals.chicken_par_fry20 + vals.rhpko20 + vals.rhpkol20 + vals.rhpkst20 + vals.shortening20 +
                        vals.rhpo20 + vals.rpst20 + vals.rhpst20 + vals.rhcno20 + vals.rcno20)
        vals.packaged20 = (vals.stote_oil_blend20 + vals.subtotal_20 + vals.ls20 + vals.nim20 + 
                            vals.nis20 + vals.is20 + vals.im20 + vals.asm20)

        vals.tvp21 = vals.bot21 + vals.mpptotal21 + vals.mpbtotal21 + vals.sf_total21 + vals.macd_system_total21
        vals.bulk21 = (vals.chicken_par_fry21 + vals.rhpko21 + vals.rhpkol21 + vals.rhpkst21 + vals.shortening21 +
                        vals.rhpo21 + vals.rpst21 + vals.rhpst21 + vals.rhcno21 + vals.rcno21)
        vals.packaged21 = (vals.stote_oil_blend21 + vals.subtotal_21 + vals.ls21 + vals.nim21 + 
                            vals.nis21 + vals.is21 + vals.im21 + vals.asm21)

        vals.tvp22 = vals.bot22 + vals.mpptotal22 + vals.mpbtotal22 + vals.sf_total22 + vals.macd_system_total22
        vals.bulk22 = (vals.chicken_par_fry22 + vals.rhpko22 + vals.rhpkol22 + vals.rhpkst22 + vals.shortening22 +
                        vals.rhpo22 + vals.rpst22 + vals.rhpst22 + vals.rhcno22 + vals.rcno22)
        vals.packaged22 = (vals.stote_oil_blend22 + vals.subtotal_22 + vals.ls22 + vals.nim22 + 
                            vals.nis22 + vals.is22 + vals.im22 + vals.asm22)

        vals.tvp23 = vals.bot23 + vals.mpptotal23 + vals.mpbtotal23 + vals.sf_total23 + vals.macd_system_total23
        vals.bulk23 = (vals.chicken_par_fry23 + vals.rhpko23 + vals.rhpkol23 + vals.rhpkst23 + vals.shortening23 +
                        vals.rhpo23 + vals.rpst23 + vals.rhpst23 + vals.rhcno23 + vals.rcno23)
        vals.packaged23 = (vals.stote_oil_blend23 + vals.subtotal_23 + vals.ls23 + vals.nim23 + 
                            vals.nis23 + vals.is23 + vals.im23 + vals.asm23)

        vals.tvp24 = vals.bot24 + vals.mpptotal24 + vals.mpbtotal24 + vals.sf_total24 + vals.macd_system_total24
        vals.bulk24 = (vals.chicken_par_fry24 + vals.rhpko24 + vals.rhpkol24 + vals.rhpkst24 + vals.shortening24 +
                        vals.rhpo24 + vals.rpst24 + vals.rhpst24 + vals.rhcno24 + vals.rcno24)
        vals.packaged24 = (vals.stote_oil_blend24 + vals.subtotal_24 + vals.ls24 + vals.nim24 + 
                            vals.nis24 + vals.is24 + vals.im24 + vals.asm24)
        
        # save the object
        vals.save()
        return render(request, 'index.html', {'vals': vals})

    # context = {'form': form} --- if want to use forms
    return render(request, 'index.html', )


# def calculate(request):
#     # vals = values.objects.all()  this will return all the objects, i dont think that is what you want
#     vals = values()
#     vals.hocan15 = float(request.POST['hocan15'])
#     vals.g1sb015 = float(request.POST['g1sb015'])
#     vals.corn15 = float(request.POST['corn15'])
#     vals.hsbo15 = float(request.POST['hsbo15'])

#     vals.stote_oil_blend15 = vals.g1sb015/(16.5*100)
#     vals.chicken_par_fry15 = (
#         vals.corn15 - vals.stote_oil_blend15*20/100)/(45/100)
#     vals.save()

#     return render(request, 'index.html', {'vals': vals})
