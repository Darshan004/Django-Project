from django.contrib import admin
from macd.models import values
# Register your models here.

admin.site.register(values)